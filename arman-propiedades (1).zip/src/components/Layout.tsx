import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Instagram, Mail, MapPin } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Inicio', path: '/' },
    { name: 'Propiedades', path: '/propiedades' },
    { name: 'Proyectos', path: '/proyectos' },
    { name: 'Tasaciones', path: '/tasaciones' },
    { name: 'Nosotros', path: '/nosotros' },
    { name: 'Contacto', path: '/contacto' },
  ];

  return (
    <nav className={cn(
      "fixed top-0 w-full z-50 transition-all duration-300",
      scrolled ? "glass-nav py-3" : "bg-transparent py-5"
    )}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex flex-col">
            <span className={cn(
              "text-2xl font-display font-bold tracking-tight leading-none",
              scrolled ? "text-brand-primary" : "text-white"
            )}>ARMAN</span>
            <span className={cn(
              "text-[10px] uppercase tracking-[0.2em] font-medium",
              scrolled ? "text-brand-secondary" : "text-white/80"
            )}>Propiedades</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-brand-primary/60",
                  location.pathname === link.path 
                    ? "text-brand-primary font-bold" 
                    : (scrolled ? "text-brand-primary" : "text-white")
                )}
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={cn(
                "p-2 rounded-md",
                scrolled ? "text-brand-primary" : "text-white"
              )}
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-b border-black/5 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={cn(
                  "block px-3 py-2 rounded-md text-base font-medium",
                  location.pathname === link.path
                    ? "text-brand-primary bg-gray-100"
                    : "text-brand-primary hover:bg-gray-50"
                )}
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export const Footer = () => {
  return (
    <footer className="bg-brand-primary text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4">
            <Link to="/" className="flex flex-col">
              <span className="text-2xl font-display font-bold tracking-tight leading-none">ARMAN</span>
              <span className="text-[10px] uppercase tracking-[0.2em] font-medium text-white/60">Propiedades</span>
            </Link>
            <p className="text-white/60 text-sm leading-relaxed">
              Gestión inmobiliaria responsable y transparente en Córdoba. Tu confianza es nuestro mayor compromiso.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="https://instagram.com/arman.propiedades" target="_blank" rel="noreferrer" className="hover:text-white/80 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="mailto:armangrupoinmobiliario@gmail.com" className="hover:text-white/80 transition-colors">
                <Mail size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-display font-semibold mb-6 text-lg">Navegación</h3>
            <ul className="space-y-3 text-white/60 text-sm">
              <li><Link to="/" className="hover:text-white transition-colors">Inicio</Link></li>
              <li><Link to="/propiedades" className="hover:text-white transition-colors">Propiedades</Link></li>
              <li><Link to="/proyectos" className="hover:text-white transition-colors">Proyectos</Link></li>
              <li><Link to="/tasaciones" className="hover:text-white transition-colors">Tasaciones</Link></li>
              <li><Link to="/nosotros" className="hover:text-white transition-colors">Nosotros</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-display font-semibold mb-6 text-lg">Servicios</h3>
            <ul className="space-y-3 text-white/60 text-sm">
              <li>Venta de Propiedades</li>
              <li>Alquileres</li>
              <li>Tasaciones Profesionales</li>
              <li>Desarrollos Inmobiliarios</li>
              <li>Asesoramiento Legal</li>
            </ul>
          </div>

          <div>
            <h3 className="font-display font-semibold mb-6 text-lg">Contacto</h3>
            <ul className="space-y-4 text-white/60 text-sm">
              <li className="flex items-start space-x-3">
                <MapPin size={18} className="shrink-0 text-white/40" />
                <span>9 de Julio 37, Córdoba, Argentina</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone size={18} className="shrink-0 text-white/40" />
                <span>+54 9 351 505 2474</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail size={18} className="shrink-0 text-white/40" />
                <span className="break-all">armangrupoinmobiliario@gmail.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-white/40">
          <p>© {new Date().getFullYear()} Arman Propiedades. Todos los derechos reservados.</p>
          <p className="mt-2 md:mt-0">Diseño y Desarrollo Profesional</p>
        </div>
      </div>
    </footer>
  );
};

export const WhatsAppButton = () => {
  return (
    <a
      href="https://wa.me/5493515052474"
      target="_blank"
      rel="noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:scale-110 transition-transform duration-300 flex items-center justify-center"
      aria-label="Contactar por WhatsApp"
    >
      <Phone size={24} />
    </a>
  );
};
