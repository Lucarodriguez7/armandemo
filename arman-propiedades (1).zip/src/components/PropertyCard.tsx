import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Maximize, BedDouble, Bath } from 'lucide-react';
import { Property } from '../data';

interface PropertyCardProps {
  property: Property;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden property-card-shadow group transition-all duration-300 hover:-translate-y-1">
      <Link to={`/propiedades/${property.id}`} className="block relative aspect-[4/3] overflow-hidden">
        <img
          src={property.images[0]}
          alt={property.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 left-4 flex gap-2">
          <span className="bg-brand-primary text-white text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded">
            {property.operation}
          </span>
          <span className="bg-white/90 backdrop-blur-sm text-brand-primary text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded">
            {property.type}
          </span>
        </div>
      </Link>
      
      <div className="p-5">
        <div className="mb-2">
          <h3 className="text-lg font-display font-bold text-brand-primary line-clamp-1 group-hover:opacity-70 transition-opacity">
            <Link to={`/propiedades/${property.id}`}>{property.title}</Link>
          </h3>
          <div className="flex items-center text-brand-secondary text-xs mt-1">
            <MapPin size={14} className="mr-1 text-brand-primary/40" />
            {property.location}
          </div>
        </div>
        
        <div className="text-xl font-bold text-brand-primary mb-4">
          {property.price}
        </div>
        
        <div className="flex items-center justify-between pt-4 border-t border-gray-100 text-brand-secondary text-xs">
          <div className="flex items-center gap-4">
            {property.bedrooms && (
              <div className="flex items-center gap-1">
                <BedDouble size={16} />
                <span>{property.bedrooms}</span>
              </div>
            )}
            {property.bathrooms && (
              <div className="flex items-center gap-1">
                <Bath size={16} />
                <span>{property.bathrooms}</span>
              </div>
            )}
            <div className="flex items-center gap-1">
              <Maximize size={16} />
              <span>{property.area}m²</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
