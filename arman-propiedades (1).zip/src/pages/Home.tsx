import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Star, Search, Instagram } from 'lucide-react';
import { motion } from 'motion/react';
import { PROPERTIES } from '../data';
import { PropertyCard } from '../components/PropertyCard';

const Home = () => {
  const navigate = useNavigate();
  const featuredProperties = PROPERTIES.filter(p => p.featured);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/propiedades');
  };

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-20">
        <div className="absolute inset-0 z-0">
          <img
            src="https://picsum.photos/seed/minimal-interior/1920/1080?grayscale"
            alt="Hero Background"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-white via-white/80 to-gray-50"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div data-aos="fade-right">
              <span className="text-brand-primary/60 font-bold uppercase tracking-[0.3em] text-xs mb-4 block">Arman Propiedades</span>
              <h1 className="text-5xl md:text-6xl lg:text-7xl text-brand-primary font-display font-bold leading-[1.1] mb-8">
                Gestión inmobiliaria <span className="text-brand-primary/40">responsable</span>
              </h1>
              <p className="text-lg md:text-xl text-brand-secondary mb-10 leading-relaxed font-light max-w-xl">
                Brindamos un servicio profesional basado en la transparencia y el compromiso que tu inversión merece en la ciudad de Córdoba.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/propiedades"
                  className="bg-brand-primary hover:bg-black text-white px-8 py-4 rounded-lg font-semibold transition-all flex items-center justify-center gap-2 group"
                >
                  Ver propiedades
                  <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link
                  to="/contacto"
                  className="bg-white hover:bg-gray-50 text-brand-primary border border-gray-200 px-8 py-4 rounded-lg font-semibold transition-all flex items-center justify-center"
                >
                  Contactanos
                </Link>
              </div>
            </div>
          </div>

          {/* Glassmorphism Search Filter */}
          <div
            data-aos="fade-up"
            data-aos-delay="200"
            className="mt-20"
          >
            <div className="glass-card p-2 rounded-2xl md:rounded-full max-w-5xl">
              <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-2">
                <div className="px-6 py-3">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-brand-primary/60 mb-1">Operación</label>
                  <select className="w-full bg-transparent text-sm font-medium text-brand-primary outline-none cursor-pointer">
                    <option>Venta</option>
                    <option>Alquiler</option>
                  </select>
                </div>
                <div className="px-6 py-3 border-t md:border-t-0 md:border-l border-black/5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-brand-primary/60 mb-1">Tipo</label>
                  <select className="w-full bg-transparent text-sm font-medium text-brand-primary outline-none cursor-pointer">
                    <option>Departamento</option>
                    <option>Casa</option>
                    <option>Terreno</option>
                    <option>Local</option>
                  </select>
                </div>
                <div className="px-6 py-3 border-t md:border-t-0 md:border-l border-black/5">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-brand-primary/60 mb-1">Ubicación</label>
                  <select className="w-full bg-transparent text-sm font-medium text-brand-primary outline-none cursor-pointer">
                    <option>Todas las zonas</option>
                    <option>Nueva Córdoba</option>
                    <option>Centro</option>
                    <option>Valle Escondido</option>
                  </select>
                </div>
                <div className="p-1">
                  <button className="w-full h-full bg-brand-primary text-white rounded-xl md:rounded-full py-4 md:py-0 px-8 text-sm font-bold hover:bg-black transition-colors flex items-center justify-center gap-2">
                    <Search size={18} />
                    Buscar Propiedad
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6" data-aos="fade-up">
            <div>
              <span className="text-brand-primary/40 font-bold uppercase tracking-widest text-xs mb-2 block">Oportunidades</span>
              <h2 className="text-3xl md:text-4xl font-display font-bold text-brand-primary">Propiedades Destacadas</h2>
            </div>
            <Link to="/propiedades" className="text-brand-primary font-semibold flex items-center gap-2 hover:underline">
              Ver todo el catálogo <ArrowRight size={18} />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProperties.map((property, idx) => (
              <div key={property.id} data-aos="fade-up" data-aos-delay={idx * 100}>
                <PropertyCard property={property} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16" data-aos="fade-up">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-brand-primary mb-6">¿Por qué elegir Arman Propiedades?</h2>
            <p className="text-brand-secondary leading-relaxed">
              Nuestra filosofía de trabajo se basa en pilares fundamentales que garantizan el éxito de cada operación inmobiliaria.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                title: 'Responsabilidad',
                desc: 'Asumimos cada compromiso con la máxima seriedad, cuidando tus intereses en todo momento.'
              },
              {
                title: 'Transparencia',
                desc: 'Información clara y honesta en cada etapa del proceso. Sin sorpresas ni costos ocultos.'
              },
              {
                title: 'Profesionalismo',
                desc: 'Contamos con la experiencia y el conocimiento del mercado necesario para asesorarte correctamente.'
              }
            ].map((benefit, idx) => (
              <div key={idx} className="text-center space-y-4" data-aos="fade-up" data-aos-delay={idx * 100}>
                <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto text-brand-primary shadow-sm">
                  <CheckCircle2 size={32} />
                </div>
                <h3 className="text-xl font-display font-bold text-brand-primary">{benefit.title}</h3>
                <p className="text-brand-secondary text-sm leading-relaxed">{benefit.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Instagram Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16" data-aos="fade-up">
            <span className="text-brand-primary/40 font-bold uppercase tracking-widest text-xs mb-2 block">Comunidad</span>
            <h2 className="text-3xl md:text-4xl font-display font-bold text-brand-primary mb-4">Seguinos en Instagram</h2>
            <p className="text-brand-secondary mb-8">Enterate de las últimas novedades y propiedades exclusivas.</p>
            <a 
              href="https://instagram.com/arman.propiedades" 
              target="_blank" 
              rel="noreferrer"
              className="inline-flex items-center gap-2 text-brand-primary font-bold hover:opacity-70 transition-opacity"
            >
              <Instagram size={20} />
              @arman.propiedades
            </a>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="aspect-square rounded-2xl overflow-hidden group relative" data-aos="zoom-in" data-aos-delay={i * 100}>
                <img 
                  src={`https://picsum.photos/seed/insta-${i}/600/600?grayscale`} 
                  alt={`Instagram post ${i}`}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Instagram className="text-white" size={32} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-brand-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16" data-aos="fade-up">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Lo que dicen nuestros clientes</h2>
            <div className="flex justify-center gap-1 text-white/40">
              {[...Array(5)].map((_, i) => <Star key={i} size={20} fill="currentColor" />)}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                name: 'Ricardo Gómez',
                text: 'Excelente atención y predisposición. Me ayudaron a encontrar mi primer departamento con mucha paciencia y profesionalismo.'
              },
              {
                name: 'María Laura S.',
                text: 'Tasaron mi propiedad de forma justa y la vendieron en tiempo récord. Muy recomendables por su seriedad.'
              }
            ].map((t, idx) => (
              <div key={idx} className="bg-white/5 p-8 rounded-2xl border border-white/10 italic" data-aos="fade-up" data-aos-delay={idx * 100}>
                <p className="text-lg mb-6 leading-relaxed">"{t.text}"</p>
                <div className="not-italic font-semibold text-white/60">— {t.name}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-24 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gray-100 rounded-[3rem] p-12 text-center text-brand-primary relative overflow-hidden" data-aos="zoom-in">
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-6">¿Tenés una propiedad para vender o alquilar?</h2>
              <p className="text-brand-secondary text-lg mb-10 max-w-2xl mx-auto">
                Realizamos tasaciones profesionales y te ayudamos a encontrar al cliente ideal para tu inmueble.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link to="/tasaciones" className="bg-brand-primary text-white px-8 py-4 rounded-lg font-bold hover:bg-black transition-colors">
                  Solicitar Tasación
                </Link>
                <Link to="/contacto" className="bg-white text-brand-primary border border-gray-200 px-8 py-4 rounded-lg font-bold hover:bg-gray-50 transition-colors">
                  Hablar con un Asesor
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
