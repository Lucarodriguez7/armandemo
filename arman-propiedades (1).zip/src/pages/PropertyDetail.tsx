import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { MapPin, Maximize, BedDouble, Bath, Phone, ArrowLeft, Share2, Heart } from 'lucide-react';
import { PROPERTIES } from '../data';

const PropertyDetail = () => {
  const { id } = useParams();
  const property = PROPERTIES.find(p => p.id === id);

  if (!property) {
    return (
      <div className="pt-32 pb-24 text-center">
        <h1 className="text-2xl font-bold">Propiedad no encontrada</h1>
        <Link to="/propiedades" className="text-brand-accent mt-4 inline-block">Volver al catálogo</Link>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-24 bg-white">
      {/* Gallery Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <div className="flex items-center justify-between mb-6">
          <Link to="/propiedades" className="flex items-center gap-2 text-brand-secondary hover:text-brand-accent transition-colors text-sm font-medium">
            <ArrowLeft size={18} />
            Volver al listado
          </Link>
          <div className="flex gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors text-brand-secondary">
              <Share2 size={20} />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors text-brand-secondary">
              <Heart size={20} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-[400px] md:h-[600px]">
          <div className="h-full rounded-2xl overflow-hidden">
            <img src={property.images[0]} alt={property.title} className="w-full h-full object-cover" />
          </div>
          <div className="hidden md:grid grid-rows-2 gap-4 h-full">
            <div className="rounded-2xl overflow-hidden">
              <img src={property.images[1] || property.images[0]} alt={property.title} className="w-full h-full object-cover" />
            </div>
            <div className="rounded-2xl overflow-hidden relative">
              <img src={property.images[0]} alt={property.title} className="w-full h-full object-cover blur-[2px]" />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <span className="text-white font-bold text-lg">Ver todas las fotos</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Info */}
          <div className="lg:col-span-2 space-y-8" data-aos="fade-up">
            <div>
              <div className="flex gap-2 mb-4">
                <span className="bg-brand-primary text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded">
                  {property.operation}
                </span>
                <span className="bg-gray-100 text-brand-primary text-xs font-bold uppercase tracking-wider px-3 py-1 rounded">
                  {property.type}
                </span>
              </div>
              <h1 className="text-3xl md:text-4xl font-display font-bold text-brand-primary mb-2">{property.title}</h1>
              <div className="flex items-center text-brand-secondary">
                <MapPin size={18} className="mr-2 text-brand-primary/40" />
                {property.location}
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 py-8 border-y border-gray-100">
              <div className="text-center sm:text-left">
                <div className="text-brand-secondary text-xs uppercase tracking-widest font-bold mb-1">Precio</div>
                <div className="text-2xl font-bold text-brand-primary">{property.price}</div>
              </div>
              <div className="text-center sm:text-left">
                <div className="text-brand-secondary text-xs uppercase tracking-widest font-bold mb-1">Superficie</div>
                <div className="text-xl font-bold text-brand-primary flex items-center justify-center sm:justify-start gap-2">
                  <Maximize size={20} className="text-brand-primary/40" />
                  {property.area} m²
                </div>
              </div>
              {property.bedrooms && (
                <div className="text-center sm:text-left">
                  <div className="text-brand-secondary text-xs uppercase tracking-widest font-bold mb-1">Dormitorios</div>
                  <div className="text-xl font-bold text-brand-primary flex items-center justify-center sm:justify-start gap-2">
                    <BedDouble size={20} className="text-brand-primary/40" />
                    {property.bedrooms}
                  </div>
                </div>
              )}
              {property.bathrooms && (
                <div className="text-center sm:text-left">
                  <div className="text-brand-secondary text-xs uppercase tracking-widest font-bold mb-1">Baños</div>
                  <div className="text-xl font-bold text-brand-primary flex items-center justify-center sm:justify-start gap-2">
                    <Bath size={20} className="text-brand-primary/40" />
                    {property.bathrooms}
                  </div>
                </div>
              )}
            </div>

            <div>
              <h3 className="text-xl font-display font-bold text-brand-primary mb-4">Descripción</h3>
              <p className="text-brand-secondary leading-relaxed whitespace-pre-line">
                {property.description}
              </p>
            </div>

            <div>
              <h3 className="text-xl font-display font-bold text-brand-primary mb-4">Ubicación</h3>
              <div className="bg-gray-100 rounded-2xl h-[300px] flex items-center justify-center text-gray-400">
                <div className="text-center">
                  <MapPin size={48} className="mx-auto mb-2 opacity-20" />
                  <p>Mapa Interactivo (Placeholder)</p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar Contact */}
          <div className="lg:col-span-1" data-aos="fade-left" data-aos-delay="200">
            <div className="sticky top-32 bg-gray-50 p-8 rounded-2xl border border-gray-100">
              <h3 className="text-xl font-display font-bold text-brand-primary mb-6">Consultar por esta propiedad</h3>
              <form className="space-y-4">
                <input
                  type="text"
                  placeholder="Nombre completo"
                  className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-brand-primary outline-none"
                />
                <input
                  type="email"
                  placeholder="Correo electrónico"
                  className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-brand-primary outline-none"
                />
                <input
                  type="tel"
                  placeholder="Teléfono"
                  className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-brand-primary outline-none"
                />
                <textarea
                  placeholder="Hola, me interesa esta propiedad..."
                  rows={4}
                  className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-brand-primary outline-none resize-none"
                ></textarea>
                <button className="w-full bg-brand-primary text-white rounded-lg px-4 py-4 font-bold hover:bg-black transition-colors">
                  Enviar Consulta
                </button>
                <div className="text-center py-2">
                  <span className="text-xs text-gray-400 font-bold uppercase tracking-widest">o también</span>
                </div>
                <a
                  href={`https://wa.me/5493515052474?text=Hola, me interesa la propiedad: ${property.title}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full bg-[#25D366] text-white rounded-lg px-4 py-4 font-bold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
                >
                  <Phone size={20} />
                  Contactar por WhatsApp
                </a>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetail;
